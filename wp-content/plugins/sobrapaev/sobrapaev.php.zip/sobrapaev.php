<?php
/**
 * Plugin name: Sobrapaev
 * Plugin URI: http://saaravallik.ikt.khk.ee/
 * Description: This is the very first plugin I ever created
 * Version: 1.0
 * Author: Saara V채llik
 * Author URI: http://saaravallik.ikt.khk.ee/
 * */
 
 ?>
 
<script src="//code.jquery.com/jquery.min.js"></script>
<script src="jquery.flurry.js"></script>

$('body').flurry();
